﻿using System;
using System.Collections.Generic;

namespace project9
{
    class Program
    {
        public class Node
        {
            public string Name;
            public int level = 0;
        }

        public static List<Node> elems = new List<Node>();

        static void Main(string[] args)
        {
            string result = "";

            Console.WriteLine("Введите выражение дерева");
            string inputTree = Console.ReadLine();

            char[] splited = inputTree.ToCharArray();
            for(int i = 0; i < splited.Length; i++)
            {
                if(splited[i] != ' ' & splited[i] != ',')
                {
                    elems.Add(new Node { Name = splited[i].ToString() });
                }
            }

            for(int i = 0; i < elems.Count; i++)
            {
                for (int j = 0; j < elems.Count; j++)
                {
                    if(elems[j].Name == elems[i].Name)
                    {
                        break;
                    }
                    if (elems[j].Name == "(")
                    {
                        elems[i].level++;
                    }
                    if(elems[j].Name == ")")
                    {
                        elems[i].level--;
                    }
                    
                }
                
            }

            for(int i = 0; i < elems.Count; i++)
            {
                if(elems[i].Name == "(" )
                {
                    elems.RemoveAt(i);
                    i--;
                }
                if (elems[i].Name == ")")
                {
                    elems.RemoveAt(i);
                    i--;
                }
            }

            for(int i = 0; i < elems.Count; i++)
            {
                string levels = "";
                for (int j = 0; j < elems[i].level; j++)
                {
                    levels += "\n" + "     ";
                }
                result += levels + elems[i].Name;
            }
            for(int i = 0; i < elems.Count; i++)
            {
                Console.WriteLine(new String(' ', elems[i].level) + elems[i].Name);
            }
        }
    }
}
